from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', my_title = 'Home')

@app.route('/about')
def about():
    return render_template('about.html', my_title = 'About')

@app.route('/contact')
def contact():
    return render_template('contact.html', my_title = 'Contact')

@app.route('/project')
def project():
    return render_template('project.html', my_title = 'Project')


if __name__ == '__main__':
    app.run(debug = True)